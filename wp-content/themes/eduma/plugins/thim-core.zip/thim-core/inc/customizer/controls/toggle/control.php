<?php
namespace ThimPress\Customizer\Control;

defined( 'ABSPATH' ) || exit;

class Toggle extends Checkbox_Switch {

	public $type = 'thim-toggle';
}
