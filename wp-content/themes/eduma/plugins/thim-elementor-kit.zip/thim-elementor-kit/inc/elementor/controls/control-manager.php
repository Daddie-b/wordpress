<?php
namespace Thim_EL_Kit\Elementor\Controls;

class Controls_Manager extends \Elementor\Controls_Manager {
	const AUTOCOMPLETE = 'thim-ekit-autocomplete';
	const IMAGE_SELECT = 'thim-ekit-image-select';
	const SELECT2      = 'thim-ekit-select2';
}
